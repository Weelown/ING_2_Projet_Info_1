#include <iostream>

#include <map>

#include <vector>

#include <cstdio>

#include <cstdlib>

#include <string>



using namespace std;

// prototype de la classe coordonnees

class Cordonnees												// Class Cordonnees

{

protected:

	string m_coordonnees

;

public:

	Cordonnees();

	Cordonnees(string _coordonnees);

	~Cordonnees();



	void set_coordonnees(string _coordonnees);



	string get_coordonnees();

};


// impl�mentation pour la classe coordonnees
Cordonnees::Cordonnees()

:m_coordonnees("00")

{}



Cordonnees::Cordonnees(string _coordonnees)

:m_coordonnees(_coordonnees)

{}



Cordonnees::~Cordonnees()

{}

void Cordonnees::set_coordonnees(string _coordonnees) {m_coordonnees = _coordonnees;}



string Cordonnees::get_coordonnees() {return m_coordonnees;}







// declaraction de la class case

class Case		:public Cordonnees

{

protected:

	bool m_libre;



public:

	Case();

	Case(string _coordonnees, bool _libre);



	void set_libre(bool _libre);

	bool get_libre();

};



Case::Case()

:Cordonnees("00"),m_libre(true)

{}



Case::Case(string _coordonnees, bool _libre)

:Cordonnees(_coordonnees),m_libre(_libre)

{}
// accesseurs



void Case::set_libre(bool _libre) {m_libre = _libre;}

bool Case::get_libre() {return m_libre;}









class Piece     :public Cordonnees              // Classe Piece

{

protected:

	float m_haut;

	float m_bas;

	float m_gauche;

	float m_droite;



public:

	Piece(string _coordonnees, float _haut, float _bas, float _gauche, float _droite);



	void set_haut(float _haut);

	void set_bas(float _bas);

	void set_gauche(float _gauche);

	void set_droite(float _droite);



	float get_haut();

	float get_bas();

	float get_gauche();

	float get_droite();

};
// impl�mentaton de la classe case



Piece::Piece(string _coordonnees, float _haut, float _bas, float _gauche, float _droite)

:Cordonnees(_coordonnees),m_haut(_haut),m_bas(_bas),m_gauche(_gauche),m_droite(_droite)

{}
// accesseurs

float Piece::get_haut() {return m_haut;}

float Piece::get_bas() {return m_bas;}

float Piece::get_gauche() {return m_gauche;}

float Piece::get_droite() {return m_droite;}



void Piece::set_haut(float _haut) {m_haut = _haut;}

void Piece::set_bas(float _bas) {m_bas = _bas;}

void Piece::set_gauche(float _gauche) {m_gauche = _gauche;}

void Piece::set_droite(float _droite) {m_droite = _droite;}






// Classe Pion (Elephant / Rhinoc�ros)


class Pion :public Piece
{

public:

	Pion(string _coordonnees, float _haut, float _bas, float _gauche, float _droite);

};

// implementation de classe pion

Pion::Pion(string _coordonnees, float _haut, float _bas, float _gauche, float _droite)

:Piece(_coordonnees,_haut,_bas,_gauche,_droite)

{}





// prototype de la classe montagne

class Montagne :public Piece

{

public:

	Montagne(string _coordonnees);

};

// implementation de la classe montagne


Montagne::Montagne(string _coordonnees)

:Piece(_coordonnees,0.9,0.9,0.9,0.9)

{}








// prototype de la classe joueur


class Joueur

{

private:

	int m_coup;

	string m_nom;



public:

	Joueur(string _nom);

	~Joueur();



	int get_coup();

	void set_coup(int _coup);



	string get_nom();

};


// implementaton de la classe joueur
Joueur::Joueur(string _nom)

:m_coup(5),m_nom(_nom)

{}



Joueur::~Joueur()

{}

// accesseurs de la classe joueur

int Joueur::get_coup() {return m_coup;}

void Joueur::set_coup(int _coup) {m_coup = _coup;}

string Joueur::get_nom() {return m_nom;}

// proc�dure d'initialisation du plateau de jeu donc de la map


void init_plateau(map<string,Case>& Init)

{

	Init["A1"] = Case("A1",true);

	Init["A2"] = Case("A2",true);

	Init["A3"] = Case("A3",true);

	Init["A4"] = Case("A4",true);

	Init["A5"] = Case("A5",true);



	Init["B1"] = Case("B1",true);

	Init["B2"] = Case("B2",true);

	Init["B3"] = Case("B3",false);

	Init["B4"] = Case("B4",true);

	Init["B5"] = Case("B5",true);



	Init["C1"] = Case("C1",true);

	Init["C2"] = Case("C2",true);

	Init["C3"] = Case("C3",false);

	Init["C4"] = Case("C4",true);

	Init["C5"] = Case("C5",true);



	Init["D1"] = Case("D1",true);

	Init["D2"] = Case("D2",true);

	Init["D3"] = Case("D3",false);

	Init["D4"] = Case("D4",true);

	Init["D5"] = Case("D5",true);



	Init["E1"] = Case("E1",true);

	Init["E2"] = Case("E2",true);

	Init["E3"] = Case("E3",true);

	Init["E4"] = Case("E4",true);

	Init["E5"] = Case("E5",true);

}


// remplissage de la map avec les pions montagnes


void init_montagne(vector<Montagne>& elem)

{

	elem.push_back(Montagne("B3"));

	elem.push_back(Montagne("B4"));

	elem.push_back(Montagne("B5"));

}


// test sur les elephants pour connaitre leur orientation

bool test_elephant(vector<Pion>& pion, string a)

{

	bool test = false;



	for(unsigned char v = 0; v < pion.size(); v++)

	{

		if(pion[v].get_coordonnees() == a)

		{

			if(pion[v].get_haut() == 1)

			{

				cout << "Eh";

			}

			else if(pion[v].get_bas() == 1)

			{

				cout << "Eb";

			}

			else if(pion[v].get_droite() == 1)

			{

				cout << "Ed";

			}

			else if(pion[v].get_gauche() == 1)

			{

				cout << "Eg";

			}

			test = true;

		}

	}



	return test;

}

// test pour les rhinoceros pour avor leur orientation

bool test_rhinoceros(vector<Pion>& pion, string a)

{

	bool test = false;



	for(unsigned char v = 0; v < pion.size(); v++)

	{

		if(pion[v].get_coordonnees() == a)

		{

			if(pion[v].get_haut() == 1)

			{

				cout << "Rh";

			}

			else if(pion[v].get_bas() == 1)

			{

				cout << "Rb";

			}

			else if(pion[v].get_droite() == 1)

			{

				cout << "Rd";

			}

			else if(pion[v].get_gauche() == 1)

			{

				cout << "Rg";

			}

			test = true;

		}

	}



	return test;

}



// proc�dure d'affichage du plateau

void affichage_plateau(map<string,Case>& Plateau, vector<Pion>& Elephant, vector<Pion>& Rhinoceros, vector<Montagne>& Montagne)

{

    // remplissage

	string a;

	cout << endl << endl << endl;

	for (char i = 'A'; i < 'F'; i++)

	{

		for (char j = '1'; j < '6'; j++)

		{

			a = "";

			a += i;

			a += j;

			if(Plateau[a].get_libre() == true)

			{

				cout << "# ";

			}

			else

			{ // affichage d'une montagne si il ne s'agit ni d'un elephant ni d'un rhino



				if(test_elephant(Elephant, a) == true)

				{}

				else if(test_rhinoceros(Rhinoceros, a) == true)

				{}

				else

				{

					cout << "M ";

				}



			}

			cout << "\t";

		}

		cout << endl << endl;

	}

}



// proc�dure de changement d'orientation des pions ( haut , bas , doite, gauche )

void changer_orientation(vector<Pion>& Element)

{

	string coord_joueur;

	unsigned char ori;

	bool ok = false;

	do

	{

		cout << endl << "Veuillez saisir la cordonnee du pion dont vous voulez modifier l'orientation";

		cin >> coord_joueur;

		for(int i = 0; i < Element.size(); i++)

		{

		    if(Element[i].get_coordonnees() == coord_joueur)

		    {
		        // blindage pour avoir une orientation correcte

		    	do

	{

	    cout << endl << "Veuillez saisir la nouvelle orientation du pion";

		cin >> ori;

	} while (ori != 'g' && ori != 'd' && ori != 'h' && ori != 'b');
// cas de l'orientation GAUCHE
	if(ori == 'g')

	{

	    Element[i].set_gauche(1);

	    Element[i].set_droite(0);

	    Element[i].set_haut(0);

	    Element[i].set_bas(0);

	}
// cas de l'orientation DROIT
	else if(ori == 'd')

	{

	   	Element[i].set_gauche(0);

	    Element[i].set_droite(1);

	    Element[i].set_haut(0);

	    Element[i].set_bas(0);

	}
// cas de l'orientation HAUT
	else if(ori == 'h')

	{

	    Element[i].set_gauche(0);

	    Element[i].set_droite(0);

	    Element[i].set_haut(1);

	    Element[i].set_bas(0);

	}
// cas de l'orienation BAS
	else if(ori == 'b')

	{

	    Element[i].set_gauche(0);

	    Element[i].set_droite(0);

	    Element[i].set_haut(0);

	    Element[i].set_bas(1);

	}

		        ok = true;

		    }

		}

	} while (ok == false);

}


// proc�dure pour la focntionnalite d'ajout d'un pion
void ajouter_pion(map<string,Case>& Plateau, vector<Pion>& Element, Joueur& player)

{

	bool ok = false;

	string coord_joueur;

	unsigned char ori;

	int coup = 0;
	// les diff�rents tests pour savoir si le joueur peut jouer

	if(player.get_coup() != 0)

	{

		do

		{

			cout << endl << endl << "Veuillez saisir les coordonnees de votre nouveau pion : " << endl;

			cin >> coord_joueur;



			if (coord_joueur != "A1" && coord_joueur != "A2" && coord_joueur != "A3" && coord_joueur != "A4" && coord_joueur != "A5" && coord_joueur != "B1" && coord_joueur != "C1" && coord_joueur != "D1" && coord_joueur != "E1" && coord_joueur != "B5" && coord_joueur != "C5" && coord_joueur != "D5" && coord_joueur != "E2" && coord_joueur != "E3" && coord_joueur != "E4"&& coord_joueur != "E5")

			{

		        cout << "Veuillez placer votre pion sur l'une des cases exterieures du plateau";

		    }

		    else

		    {

		        if(Plateau[coord_joueur].get_libre() == true)

		        {

		            Plateau[coord_joueur].set_libre(false);

		            coup = player.get_coup();

		            coup -= 1;

		            player.set_coup(coup); // � adapter avec une m�thode joueur

		            ok = true;

		            do

		            {

		            	cout << endl << "Veuillez saisir l'orientation de votre nouveau pion : " << endl;

						cin >> ori;

		            }while(ori != 'g' && ori != 'd' && ori != 'h' && ori != 'b');

		            if(ori == 'g')

		            {

		           		Element.push_back(Pion(coord_joueur,0,0,1,0));

		            }

		            if(ori == 'd')

		            {

		           		Element.push_back(Pion(coord_joueur,0,0,0,1));

		            }

		            if(ori == 'h')

		            {

		           		Element.push_back(Pion(coord_joueur,1,0,0,0));

		            }

		            if(ori == 'b')

		            {

		           		Element.push_back(Pion(coord_joueur,0,1,0,0));

		            }



		        }

		        else // si la case est occup�e � coder !!

		        {

		            if(coord_joueur[1] == 1)

		            {



		            }

		        }

		    }

		}while(ok == false);

	}

	else

	{
// max de pions en jeu atteint
		cout << "Impossible, vous avez d�j� 5 pions sur le plateau";

	}



}



void deplacer_pion(map<string,Case>& Plateau, vector<Pion>& Element1, vector<Pion>& Element2, vector<Montagne>& Montagne, Joueur& J1)

{
// Recuperation de la position du pion � d�placer
	string coord_joueur = "";

	bool test = false;

	unsigned char ori = 0;

	int vect = 0;

	int force;

	bool boucle = true;

	do

	{

		cout << endl << endl << "Veuillez saisir les coordonnees du pion a deplacer : " << endl;

		cin >> coord_joueur;

		for(int i = 0; i < Element1.size(); i++)

		{
// test pour etre sur qu'il s'agit d'une coordonn�e valide
		    if(Element1[i].get_coordonnees() == coord_joueur)

		    {

		        test = true;

		        vect = i;

		    }

		    else

		    {

		    	cout << "La case saisie ne contient pas de pions a vous, veuillez saisir des coordonnees correctes." << endl;

		    }

		}

	}while(test == false);



	cout << endl << "Veuillez saisir la direction dans laquelle vous voulez aller : " << endl;

	do

	{

		cin >> ori;

	}while(ori != 'g' && ori != 'd' && ori != 'h' && ori != 'b');



	cout << ori;



	if(ori == 'h')

	{

		if(coord_joueur[0] == 'A')

		{

		    Plateau[coord_joueur].set_libre(true);

		    J1.set_coup(J1.get_coup() + 1);

		    Element1[vect] = Element1[Element1.size() - 1];

		    Element1.pop_back();

		}

		else

		{

			force = Element1.get_haut();

			do

			{

			    coord_joueur[0] -= 1;

			    if(Case[coord_joueur].get_libre() == true)

			    {

			        Element1.set_coordonnees(coord_joueur);

			        Case(coord_joueur).set_libre(false);

			        coord_joueur[0] += 1;

			        Case(coord_joueur).set_libre(true);

			    }

			} while (boucle == true);





		}

	}

	if(ori == 'b')

	{

		if(coord_joueur[0] == 'E')

		{

		    Plateau[coord_joueur].set_libre(true);

		    J1.set_coup(J1.get_coup() + 1);

		    Element1[vect] = Element1[Element1.size() - 1];

		    Element1.pop_back();

		}

	}

	if(ori == 'g')

	{

		if(coord_joueur[1] == '1')

		{

		    Plateau[coord_joueur].set_libre(true);

		    J1.set_coup(J1.get_coup() + 1);

		    Element1[vect] = Element1[Element1.size() - 1];

		    Element1.pop_back();

		}

	}

	if(ori == 'd')

	{

		if(coord_joueur[1] == '5')

		{

		    Plateau[coord_joueur].set_libre(true);

		    J1.set_coup(J1.get_coup() + 1);

		    Element1[vect] = Element1[Element1.size() - 1];

		    Element1.pop_back();

		}

	}

}
// boucle de jeu




void jouer(map<string,Case>& Plateau, vector<Pion>& Element, vector<Pion>& Element2, vector<Montagne>& Montagne, Joueur& player)

{

	int choix = 0;

	cout << "Au tour de " << player.get_nom() << " de jouer" << endl << endl;

	cout << "1. Ajouter pion" << endl;

	cout << "2. Changer l'orientation d'un pion" << endl;

	cout << "3. Deplacer un pion" << endl;

	do

	{

	cin >> choix;

	if(choix == 2 && player.get_coup() == 5)

	{

	    cout << "Vous n'avez aucun pion sur le plateau, revoyez votre choix" << endl << endl;

	    choix = 0;

	}

	} while (choix != 1 && choix != 2 && choix != 3);



	if(choix == 1)

	{

	    ajouter_pion(Plateau, Element, player);

	}

	else if(choix == 2)

	{

		changer_orientation(Element);

	}

	else

	{

		deplacer_pion(Plateau, Element, Element2, Montagne, player);

	}

	system("pause");



}



void Siam()

{

	string p1, p2;

	unsigned char win = 0;



	cout << "Entrez le nom du joueur 1" << endl;

	cin >> p1;



	system("cls");



	cout << "Entrez le nom du joueur 2" << endl;

	cin >> p2;



	system("cls");



	Joueur Player_1(p1), Player_2(p2);



	cout << endl << Player_1.get_nom() << " joue les Elephants" << endl;

	cout << endl << Player_2.get_nom() << " joue les Rhinoceros" << endl << endl;



	system("pause");

	system("cls");



	map<string,Case> Plateau;			// D�claration des conteneurs

	vector<Pion> Elephant;

	vector<Pion> Rhinoceros;

	vector<Montagne> Montagne;



	init_plateau(Plateau);				// Initialisation des conteneurs

	init_montagne(Montagne);





	do

	{

	affichage_plateau(Plateau,Elephant,Rhinoceros,Montagne);

	jouer(Plateau,Elephant, Rhinoceros, Montagne, Player_1);

	system("cls");

	if(Montagne.size() == 2)

	{

		win = 1;

	}

	if(win == 0)

	{

	affichage_plateau(Plateau,Elephant,Rhinoceros,Montagne);

	jouer(Plateau,Rhinoceros, Elephant, Montagne, Player_2);

		system("cls");

	}

	if(Montagne.size() == 2 && win == 0)

	{

		win = 2;

	}

	}while(win != 1 && win != 2);



	if(win == 1)

	{

	    cout << "Bravo, " << Player_1.get_nom() << " a gagne";

	}

	else

	{

		cout << "Bravo, " << Player_2.get_nom() << " a gagne";

	}



	system("pause");

}


// proc�dure d'affichage des r�gles du jeu
void regle()

{
 cout << " Chaque joueur choisit son animal. Les joueurs joueront � tour de r�le. \n "<< endl;
 cout << "Au d�but du jeu les animaux sont dispos�s � l'ext�rieur du plateau et les montagnes au centre du plateau. \n"<<endl;
 cout <<"Chaque case du plateau est rep�r�e par ses coordonn�es : ligne A � E, colonne 1 � 5. \n"<< endl;
 cout << " Les �l�phants blancs, animaux sacr�s dans le royaume de SIAM commenceront � jouer.\n "<< endl ;
 cout << "Les joueurs ne pourront jouer � chaque tour de jeu qu'un seul de leur animal et ne faire qu'une des 5 actions suivantes :\n " << endl ;
 cout <<"- Entrer un de ses animaux sur le plateau \n" << endl ;
 cout <<"- Se d�placer sur une case libre  Changer l'orientation de son animal sans changer de case \n"<<endl;
 cout <<"- Changer l'orientation de son animal sans changer de case \n"<<endl;
 cout <<"- Sortir un de ses animaux dispos�s sur une case ext�rieure (case avec un +)\n"<<endl;
 cout << "- Se d�placer en poussant d'autres pi�ces dispos�es sur le plateau \n"<<endl ;
 cout << "- Entrer un de ses animaux sur le plateau \n"<< endl;
 cout << "Vous devez entrer un de vos animaux par l'une des cases ext�rieures \n"<< endl ;
cout <<" Deux cas peuvent se pr�senter : \n " <<endl;
cout << "- Soit la case est libre et dans ce cas vous pouvez placer votre animal en l'orientant dans la direction de votre choix\n "<< endl;
cout << " Pour placer l�animal dans une case, vous saisirez au clavier ses coordonn�es correctes.  Pour orienter l�animal, il faut saisir l�une des 4 directions choisies."<<endl;
cout << "La validation se fera avec la touche Entr�e"<< endl ;
cout << " - Soit la case est occup�e et vous pouvez sous certaines conditions rentrer en effectuant une pouss�e \n"<< endl ;







}

   //  main avec le menu qui offre diff�rentes posssibilit�s

int main()

{

	int choix = 0;

	do

	{

	system("cls");

	cout << "***Menu***" << endl << endl;

	cout << "1. Jouer" << endl;

	cout << "2. Lire les regles" << endl;

	cout << "3. Quitter" << endl << endl;

	cin >> choix;

	if(choix == 1)

	{ // appel de la boucle de jeu

		system("cls");

		Siam();

	}

	if(choix == 2)

	{ // affichage des r�gles du jeu

		system("cls");

	    regle();

	}

	}while(choix != 3);



    return 0;

}
